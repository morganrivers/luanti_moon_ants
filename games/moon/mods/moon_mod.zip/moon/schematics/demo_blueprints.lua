-- -- local bonds = dofile(minetest.get_modpath("moon").."/nodes/bonds.lua")
-- local bond_types = dofile(minetest.get_modpath("moon").."/bonds/types.lua")
-- local bond_registry = dofile(minetest.get_modpath("moon").."/bonds/registry.lua")
-- local bond_api = dofile(minetest.get_modpath("moon").."/bonds/api.lua")


-- -- MAYBE WRONG?

-- local ports = dofile(minetest.get_modpath("moon").."/ports/registry.lua")
-- local voxels = dofile(minetest.get_modpath("moon").."/voxels/metadata.lua")
-- local MATERIAL = moon.MATERIAL
-- local BOND = moon.BOND
-- local PORT = moon.PORT

-- local function px(pos, x, y, z)
--     return {x=pos.x + x, y=pos.y + y, z=pos.z + z}
-- end

-- local function place_rc_demo(pos)
--     -- Place three conductor voxels in a +X line, assign correct meta
--     local p1 = px(pos,0,0,0)
--     local p2 = px(pos,1,0,0)
--     local p3 = px(pos,2,0,0)
--     minetest.set_node(p1, {name="moon:conductor_voxel"})
--     minetest.set_node(p2, {name="moon:conductor_voxel"})
--     minetest.set_node(p3, {name="moon:conductor_voxel"})
--     -- Set voxel metadata (conductor, material)
--     voxels.metadata.write(p1, {flags=MATERIAL.Cu, material_id=MATERIAL.Cu})
--     voxels.metadata.write(p2, {flags=MATERIAL.Cu, material_id=MATERIAL.Cu})
--     voxels.metadata.write(p3, {flags=MATERIAL.Cu, material_id=MATERIAL.Cu})
--     -- R-bond 1-2 (100 Ω)
--     bonds.api.create(p1, p2, BOND.ELECTRIC, {resistance_ohm=100})
--     -- C-bond 2-3 (1 mF)
--     bonds.api.create(p2, p3, BOND.ELECTRIC, {capacitance_f=0.001})
--     -- Add POWER port to voxel 1 (voltage=5)
--     ports.registry.add(p1, PORT.POWER, {voltage=5})
--     -- Add POWER port to voxel 3 (voltage=0, current_A=0)
--     ports.registry.add(p3, PORT.POWER, {voltage=0, current_A=0})
-- end

-- local function place_wheel_demo(pos)
--     -- Place motor coil (conductor+ACTUATOR), shaft, wheel
--     local p1 = px(pos,0,0,0)
--     local p2 = px(pos,1,0,0)
--     local p3 = px(pos,2,0,0)
--     minetest.set_node(p1, {name="moon:conductor_voxel"})
--     minetest.set_node(p2, {name="moon:shaft_voxel"})
--     minetest.set_node(p3, {name="moon:wheel_voxel"})
--     voxels.metadata.write(p1, {flags=MATERIAL.Cu, material_id=MATERIAL.Cu})
--     voxels.metadata.write(p2, {flags=MATERIAL.Steel, material_id=MATERIAL.Steel})
--     voxels.metadata.write(p3, {flags=MATERIAL.Steel, material_id=MATERIAL.Steel})
--     -- Add ACTUATOR port to coil (command=100)
--     ports.registry.add(p1, PORT.ACTUATOR, {command=100})
--     -- SHAFT bond coil <-> shaft, shaft <-> wheel
--     bonds.api.create(p1, p2, BOND.SHAFT, {ratio=1})
--     bonds.api.create(p2, p3, BOND.SHAFT, {ratio=1})
-- end

-- return {
--     place_rc_demo = place_rc_demo,
--     place_wheel_demo = place_wheel_demo
-- }


-- demo_placements.lua
-- Example helper to spawn a small RC circuit and a wheel‑via‑shaft assembly
-- in‑world using the **new** bonds and ports APIs.
--
-- Place the file anywhere inside the “moon” mod and require it from a chat
-- command or ABM, e.g. `local demos = dofile(minetest.get_modpath("moon").."/demo_placements.lua")`.
--
-- The implementation mirrors the contracts exercised by the automated test
-- suite (tests/test_ports.lua and tests/test_bonds.lua).

---------------------------------------------------------------------
-- dependencies ------------------------------------------------------
---------------------------------------------------------------------
local util            = dofile(minetest.get_modpath("moon") .. "/util.lua")

-- Bonds
local bond_types      = dofile(minetest.get_modpath("moon") .. "/bonds/types.lua")
local bond_api        = dofile(minetest.get_modpath("moon") .. "/bonds/api.lua")

-- Ports
local port_types      = dofile(minetest.get_modpath("moon") .. "/ports/types.lua")
local ports_registry  = dofile(minetest.get_modpath("moon") .. "/ports/registry.lua")

-- Voxels metadata helper
local vox_meta        = dofile(minetest.get_modpath("moon") .. "/voxels/metadata.lua")

-- Material constants (exposed globally by the mod’s bootstrap)
local MATERIAL        = moon.MATERIAL

-- Cube‐face enumeration used everywhere in the code‑base
local NEG_X, POS_X  = 0, 1
local NEG_Y, POS_Y  = 2, 3
local NEG_Z, POS_Z  = 4, 5

---------------------------------------------------------------------
-- small helpers -----------------------------------------------------
---------------------------------------------------------------------
local function px(p, dx, dy, dz)
  -- Shorthand for translating positions
  return {x = p.x + dx, y = p.y + dy, z = p.z + dz}
end

local function add_port(pos, face, class, state)
  ports_registry.add(util.hash(pos), face, class, state)
end

local function bind(pa, fa, pb, fb, btype, params)
  bond_api.create(pa, fa, pb, fb, btype, params)
end

---------------------------------------------------------------------
-- public demo builders ---------------------------------------------
---------------------------------------------------------------------
--- Spawn a 3‑voxel RC circuit: 5 V source → 100 Ω → 1 mF → GND.
-- * `pos` – world position of the **source** voxel.
local function place_rc_demo(pos)
  local p_src = px(pos, 0, 0, 0)
  local p_mid = px(pos, 1, 0, 0)
  local p_gnd = px(pos, 2, 0, 0)

  -- voxels
  minetest.set_node(p_src, {name = "moon:conductor_voxel"})
  minetest.set_node(p_mid, {name = "moon:conductor_voxel"})
  minetest.set_node(p_gnd, {name = "moon:conductor_voxel"})

  -- metadata (Cu / C for variety)
  vox_meta.write(p_src, {flags = MATERIAL.Cu, material_id = "Cu"})
  vox_meta.write(p_mid, {flags = MATERIAL.C,  material_id = "C"})
  vox_meta.write(p_gnd, {flags = MATERIAL.Cu, material_id = "Cu"})

  -- ports exposed on the +Y face for convenient probing
  add_port(p_src, POS_Y, port_types.POWER, {voltage = 5.0, current_A = 0})
  add_port(p_mid, POS_Y, port_types.POWER, {voltage = 0.0, current_A = 0})
  add_port(p_gnd, POS_Y, port_types.POWER, {voltage = 0.0, current_A = 0})

  -- bonds – note the opposite faces (+X ↔ −X)
  bind(p_src, POS_X, p_mid, NEG_X, bond_types.ELECTRIC, {R = 100.0})   -- resistor
  bind(p_mid, POS_X, p_gnd, NEG_X, bond_types.ELECTRIC, {C = 1e-3})   -- capacitor
end

--- Spawn a simple motor‑shaft‑wheel line.
-- * `pos` – world position of the **coil** voxel.
local function place_wheel_demo(pos)
  local p_coil  = px(pos, 0, 0, 0)
  local p_shaft = px(pos, 1, 0, 0)
  local p_wheel = px(pos, 2, 0, 0)

  -- voxels
  minetest.set_node(p_coil,  {name = "moon:conductor_voxel"})
  minetest.set_node(p_shaft, {name = "moon:shaft_voxel"})
  minetest.set_node(p_wheel, {name = "moon:wheel_voxel"})

  vox_meta.write(p_coil,  {flags = MATERIAL.Cu,    material_id = "Cu"})
  vox_meta.write(p_shaft, {flags = MATERIAL.Steel, material_id = "Steel"})
  vox_meta.write(p_wheel, {flags = MATERIAL.Steel, material_id = "Steel"})

  -- actuator command on the coil (again the +Y face)
  add_port(p_coil, POS_Y, port_types.ACTUATOR, {command = 100})

  -- rigid shaft bonds (ratio 1:1)
  bind(p_coil,  POS_X, p_shaft, NEG_X, bond_types.SHAFT, {ratio = 1})
  bind(p_shaft, POS_X, p_wheel, NEG_X, bond_types.SHAFT, {ratio = 1})
end

---------------------------------------------------------------------
return {
  place_rc_demo    = place_rc_demo,
  place_wheel_demo = place_wheel_demo,
}
